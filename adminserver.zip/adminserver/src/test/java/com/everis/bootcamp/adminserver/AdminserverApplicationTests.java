package com.everis.bootcamp.adminserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
