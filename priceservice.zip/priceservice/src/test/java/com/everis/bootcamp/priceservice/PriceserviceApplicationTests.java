package com.everis.bootcamp.priceservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PriceserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
